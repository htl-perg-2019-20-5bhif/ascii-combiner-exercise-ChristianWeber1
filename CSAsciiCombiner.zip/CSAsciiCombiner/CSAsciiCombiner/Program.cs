﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace CSAsciiCombiner
{
    class Program
    {

        static async Task Main(string[] args)
        {
            bool res;
            string[] content = null;
            string[] nextText;
            if(args.Length>1)
            {
                content = await fileToStringArray(args[0]);
                
                for (int i=1; i<args.Length; i++)
                {
                    nextText = await fileToStringArray(args[i]);
                    if (content.Length == nextText.Length)
                    {
                        content = CombineText(content, nextText);
                    }
                    else
                    {
                        throw new System.ArgumentException("Files do not have the same height!");
                    }
                    
                }
                printStringArray(content);

            } else
            {
                throw new System.ArgumentException("Not enough arguments");
            }
            
            
        }

        private static void printStringArray(string[] content)
        {
            foreach (string line in content)
            {
                Console.WriteLine(line);
            }
        }

        private static string[] CombineText(string[] content, string[] nextText)
        {
            for (int i = 0; i < content.Length; i++)
            {
                content[i] = CombineLines(content[i], nextText[i]);
            }

            return content;
                
        }

        private static string CombineLines(string v1, string v2)
        {
            string ret = "";
            char first;
            char second;
            if (v1.Length==v2.Length)
            {
                for(int i=0; i<v1.Length;i++)       
                {
                    first = v1[i];
                    second = v2[i];
                    if(first.Equals(' '))   //| + +|- - |
                    {
                        ret += second;
                    } else
                    {
                        ret += first;
                    }

                }
                return ret;
            } else
            {
                throw new System.ArgumentException("Files do not have the same size!");
            }
        }

        private static async Task<string[]> fileToStringArray(string fileName)
        {
            string content;
            try
            {
                content = await System.IO.File.ReadAllTextAsync(@"TestData\"+fileName);
            }
            catch (FileNotFoundException ex)
            {
                throw new System.ArgumentException("File does not exist!  "+ex.Message);
                throw;
            }

            return content
                .Replace("\r", string.Empty)
                .Split('\n'); ;
        }

    }
}
